# What's in this example
- Interactive
- Create new input stream every line.
- Do not build AST tree

# How to run
```
% python calc.py
1+2*3
7
var=10
var*100
1000
^Z
```