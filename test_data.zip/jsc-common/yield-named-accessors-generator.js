function *t1() {
    let object = {
        get yield() {
        },
        set yield(value) {
        }
    }
}
function *t2() {
    "use strict";
    let object = {
        get yield() {
        },
        set yield(value) {
        }
    }
}
