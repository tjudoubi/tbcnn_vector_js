function main() {
    const arr = [0];
    function executor(resolve, ...reject) {
        arr;
        if (resolve > arr) {
            const fn = () => {
                return fn;
            };
            for (const _ of arr) {
                function fn() {}
                arr.toString(arr, arr, arr, arr, arr, arr);
                throw new Error();
            }
        } else {
            for (const _ of [arr]) {
                arr.toString();
            }
            const fn = () => {};
        }
        new Promise(executor, arr);
        let some = {};
        with(arr) {}
        return reject;
    }
    executor();

    for (let i = 0; i < 100; i++) {
        executor();
    }
}
main();
