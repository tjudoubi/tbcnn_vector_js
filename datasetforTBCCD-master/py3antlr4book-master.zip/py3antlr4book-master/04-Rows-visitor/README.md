# What's in this example
- With embedded python actions
- local variable and initialization
- get column from command line and set in parser
- Do not build tree

# How to Run
```
% python col.py 1 t.rows
parrt
tombu
bke

% python col.py 2 t.rows
Terence Parr
Tom Burns
Kevin Edgar

% python col.py 3 t.rows
101
020
008
```