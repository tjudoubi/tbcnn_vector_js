
function compareArray(a, b) {
    if (b.length !== a.length) {
        return;
    }
    for (var i = 0; i < a.length; i++) {
        b[0];
    }
}
compareArray([], [0]);
compareArray([0, 'b'].copyWithin(), ['a', 0]);
compareArray([0], [1.1]);
runString('');
for (var i = 0; i < 1e6; ++i);
