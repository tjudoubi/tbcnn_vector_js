function __getRandomObject() {
    for (let obj of __getObjects()) {
    }
}
function __getRandomProperty() {
    let properties = __getproperties(obj);
    return properties[seed % properties.length];
}
try {
} catch (e) {
    this.WScript = new Proxy({}, { });
}
(function () { function ValueOf() { switch (value) { } } })(this);

(function (global) { })(this);

function f1() {
    v = v.map(() => { })
}

try {
    f1();
} catch (e) {}

try {
    f1();
} catch (e) {}

try {
    __getRandomObject(983831)[__getRandomProperty(__getRandomObject(983831))]();
} catch (e) {}

if (!'next') throw "Error: iterator prototype should have next method.";

function f2() {
    var v = a[0];
    if (v.next !== a[randoF2].next) throw "Error: next method is not the same.";
}
var a1 = [];
var sym = a1[Symbol.iterator]();
try {
    __callRandomFunction(keys, 457796, keys, __getRandomObject(860068), keys, true, __getRandomObject(32567), -1073741825, null);
    Object.defineProperty(keys, __getRandomProperty(), { });
    f2([a1[Symbol.iterator](),
             keys.keys(), a1.entries()]);
} catch (e) {}

var set1 = new Set([]);
var sym = set1[Symbol.iterator]();
var keys = set1.keys();
var entries = set1.entries();
try {
    f2([set1[Symbol.iterator](), set1.keys(), set1.entries()]);
} catch (e) {}

var map1 = new Map();
try {
    [[][  -10], [][ 2][ 1]].forEach();
} catch (e) {}
var sym = map1[Symbol.iterator]();
var keys = map1.keys();
var entries = map1.entries();
try {
    f2([map1[Symbol.iterator](), map1.keys(), map1.entries()]);
} catch (e) {}

function f3() {
    if (vl !== vl) throw new Error('bad value: ' + JSON.stringify(__v_19176));
}

var arr2 = [];
function f4() {
    arr2.push(randov)
    arr2.push(randov)
}
try {
    f4`Hello`;
} catch (e) {}
try {
    f4`World`;
    f4`Hello`;
} catch (e) {}
try {
    __callRandomFunction(arr2, 247938, set1, new Boolean(true), __getRandomObject(692620), -1e-15, __getRandomObject(276888));
} catch (e) {}
if (set1 != null && typeof set1 == "object") try {
    Object.defineProperty(set1, __getRandomProperty(), {
    });
    f3();
    f3(arr2[0] !== arr2[1]);
    f3(arr2[0] !== arr2[2]);
    f4`Hello\n`;
    f4`Hello\r`;
} catch (e) {}
try {
    f3(arr2[1] !== arr2[2]);
} catch (e) {}
if (a1 != null && typeof a1 == "object") try {
    Object.defineProperty(a1, __getRandomProperty(), {
    });
} catch (e) {}
try {
    f3(arr2[1] !== arr2[3]);
} catch (e) {}
try {
    f3(arr2[2] !== arr2[3]);
} catch (e) {}
try {
    eval("tag`Hello\n${v}world`");
    eval("tag`Hello\n${v}world`");
    f3();
    f3(arr2[0] !== arr2[1]);
} catch (e) {}
try {
    arr10[1][1] = set1 * 100 + 1 * 10 + 1;
} catch (e) {}
try {
    arr10[1][1] = set1 * 100 + 1 * 10 + 1;
} catch (e) {}
try {
    eval("tag`Hello${v}\nworld`");
    eval("tag`Hello${v}\nworld`");
    eval("tag`Hello\n${v}world`");
    delete a1[__getRandomProperty()]();
} catch (e) {}
try {
    106779[__getRandomProperty()]();
} catch (e) {}
try {
    entries[__getRandomProperty()]();
} catch (e) {}
try {
    set1[__getRandomProperty()]();
} catch (e) {}
try {
    f3();
} catch (e) {}
arr2[0] !== arr2[1]
gc();
for (arr10 = 0; arr10 < 3; ++arr10) {
    try {
    } catch (e) {}

}
try {
    f4`Hello${
        4}world`;
} catch (e) {}
for (var counter = 0x10000; counter < 0x10ffff; ++counter) {
    var charCode = String.fromCharCode();
}
