var args = "y,".repeat(30000);
var g = Function(args, "return 0");
g();
