

for (var i = 0; i < 10000; i++)
    ''.toLocaleLowerCase.call(-1, 0);
