var __v_6388 = class __c_95 {
};
var __v_6392 = class __c_97 extends __v_6388 {
  constructor() {
    var __v_6407 = () => {
        try {
          __v_6386();
        } catch (e) {}
        try {
          super.foo = 'q';
        } catch (e) {}
        super()
        try {
          this.idValue
        } catch (e) {}
    };
    __v_6407();
  }
};
for (var i = 0; i < 1000; ++i) {
    new __v_6392()
}
