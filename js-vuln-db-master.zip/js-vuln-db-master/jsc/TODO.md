
- [CVE-2014-1300](https://bugs.chromium.org/p/project-zero/issues/detail?id=77&can=1&q=webkit&redir=1)
- [??](http://googleprojectzero.blogspot.kr/2014/07/pwn4fun-spring-2014-safari-part-i_24.html)
