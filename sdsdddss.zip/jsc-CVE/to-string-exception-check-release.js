

let s = new String();
s.toString = ()=>{}
JSON.stringify(s);
