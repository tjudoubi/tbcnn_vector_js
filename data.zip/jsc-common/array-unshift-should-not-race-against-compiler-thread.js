let x = [];
for (let i = 0; i < 30; ++i) {
    for (let j = 0; j < 20000; ++j) {
        x[0]
        x.unshift(undefined);
    }
}
