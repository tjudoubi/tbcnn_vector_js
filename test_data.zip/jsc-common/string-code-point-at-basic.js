function test(string, index)
{
    return string.codePointAt(index);
}
