# Label Rule Alternative

# How to Run
```
antlr4py3 -visitor LExpr.g4
python test_EvalVistor.py t.expr
python test_EvalListener.py t.expr
python test_EvalContext.py t.expr
```