enum Temp { HOT, COLD }
