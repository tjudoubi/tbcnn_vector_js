function* avocado_1() {}

function apricot_0(alpaca_0) {
  if (alpaca_0) {}
}

class __c_0 extends null {}

function banana_2() {
  apricot_0();
  avocado_1(() => null);
}

for (let i = 0; i < 100000; i++) {
  banana_2();
}
