# What's in This Example
- pass parameter to rule
- local variable
- semantic predication: 1st data decide the number of data followed

# How to Run
```
% type t.data
2 9 10 3 1 2 3
% python test_data.py t.data
(top 
  (group 2 (sequence 9 10)) 
  (group 3 (sequence 1 2 3))
)
```