class Student{
        constructor(name,age,sex){
            this.name = name
            this.age= age
            this.sex = sex
        }

        read(){console.log(this.name+this.age+this.sex)}
    }
    var Tom =new Student('tom',21,'男')
    Tom.read()
/*var mycars=new Array()
mycars[xx[ss]]="Saab"
mycars[1]="Volvo"
mycars[2]="BMW"*/
z = x + 2;
